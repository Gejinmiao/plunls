/**
 * The channel contract every external IM connector implements. A "channel"
 * is one conversation surface (WeChat, Telegram, Slack, …) that can receive
 * user messages and send agent replies. The bridge in this package owns the
 * mapping from external conversations to live agents, so a channel
 * implementation is deliberately thin: start/stop, send, and the inbound
 * message subscription.
 *
 * @module @neko/neko-channel-host/channel
 */
/** One channel's connection lifecycle. */
export type ChannelStatus = 'offline' | 'connecting' | 'online';
/** A user message arriving from an external conversation. */
export interface ChannelInboundMessage {
    /** The channel's stable id (`channel.id`). */
    readonly channelId: string;
    /** The external conversation id inside this channel (contact/room id). */
    readonly conversationId: string;
    /** The sender's display name, when the platform provides one. */
    readonly senderName?: string;
    /** The text the user sent. */
    readonly text: string;
}
/**
 * An external conversation surface.
 *
 * Implementations own platform login, QR scanning, event listeners, and the
 * low-level send calls; the bridge consumes {@link ChannelInboundMessage}
 * events and answers through {@link send}. A channel may be registered at any
 * time; the host calls {@link start} once after registration (and {@link stop}
 * on teardown).
 */
export interface Channel {
    /** Stable channel id used in conversation keys (`wechat`, …). */
    readonly id: string;
    /** Human-readable display name (`微信`, …). */
    readonly name: string;
    /** Current connection status; mirrors every transition to listeners. */
    readonly status: ChannelStatus;
    /**
     * Connect (and authenticate, e.g. drive QR login) and begin delivering
     * messages. Resolves once the channel is online; rejects on fatal failure.
     */
    start(): Promise<void>;
    /** Disconnect and release platform resources. */
    stop(): Promise<void>;
    /** Send one text reply back into an external conversation. */
    send(conversationId: string, text: string): Promise<void>;
    /** Subscribe to inbound messages; returns the unsubscribe function. */
    onMessage(listener: (message: ChannelInboundMessage) => void): () => void;
    /** Subscribe to status transitions; returns the unsubscribe function. */
    onStatus(listener: (status: ChannelStatus) => void): () => void;
}
/** One channel's management snapshot for the Web settings surface. */
export interface ChannelSnapshot {
    /** The channel's stable id (`channel.id`). */
    readonly id: string;
    /** Human-readable display name (`微信`). */
    readonly name: string;
    /** Current connection status. */
    readonly status: ChannelStatus;
    /** Logged-in account identifier, when the channel has one. */
    readonly accountId?: string;
    /** QR image URL presented while a login is pending. */
    readonly qrcodeUrl?: string;
    /** Human-readable progress/error line for the current login state. */
    readonly message?: string;
}
/**
 * A channel that exposes lifecycle management (re-login, logout) to the Web
 * settings surface. Connectors that support operator-driven re-authentication
 * implement this alongside {@link Channel}; the admin gateway uses the
 * optional capability rather than extending every channel contract.
 */
export interface ChannelAdmin extends Channel {
    /** A current management snapshot. */
    snapshot(): ChannelSnapshot;
    /** Drop stored credentials and drive a fresh login (e.g. a new QR scan). */
    relogin(): Promise<void>;
    /** Drop stored credentials and disconnect. */
    logout(): Promise<void>;
}
//# sourceMappingURL=channel.d.ts.map