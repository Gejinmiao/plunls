/**
 * Channel management panel, browser half: a Settings section listing every
 * registered channel with its live status and management actions (QR login,
 * re-login, logout) driven through the generated `channelAdmin` Remote.
 *
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@neko/neko-client-runtime/client';
import { type ChannelsLocaleKey } from './locales.ts';
export type { ChannelsSettingsSectionInjected, ChannelsSettingsSectionProps } from './ChannelsSettingsSection.tsx';
export type { ChannelsLocaleKey } from './locales.ts';
declare module '@neko/neko-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The channel management panel. */
        'settings.channels': ChannelsLocaleKey;
    }
}
/** Dictionary namespace owned by this plugin. */
export declare const NS = "settings.channels";
/** Services required by the Settings registration and generated Remote face. */
export declare const inject: string[];
/** Contribute the channel management page to the Settings section list. */
export declare function apply(ctx: ClientContext): Promise<void>;
//# sourceMappingURL=index.d.ts.map