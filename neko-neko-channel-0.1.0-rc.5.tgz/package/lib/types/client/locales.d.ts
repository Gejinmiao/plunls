/** Copy dictionaries for the channels Settings section. */
/** Simplified Chinese dictionary and key source of truth. */
export declare const zh: {
    nav: string;
    loading: string;
    error: string;
    retry: string;
    empty: string;
    status: string;
    online: string;
    offline: string;
    connecting: string;
    account: string;
    unknownAccount: string;
    qrcode: string;
    qrcodeHint: string;
    relogin: string;
    reloginConfirm: string;
    logout: string;
    logoutConfirm: string;
    message: string;
    noMessage: string;
};
/** Channels locale key union. */
export type ChannelsLocaleKey = keyof typeof zh;
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    nav: string;
    loading: string;
    error: string;
    retry: string;
    empty: string;
    status: string;
    online: string;
    offline: string;
    connecting: string;
    account: string;
    unknownAccount: string;
    qrcode: string;
    qrcodeHint: string;
    relogin: string;
    reloginConfirm: string;
    logout: string;
    logoutConfirm: string;
    message: string;
    noMessage: string;
};
//# sourceMappingURL=locales.d.ts.map