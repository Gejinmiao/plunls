/**
 * Channels settings section: lists every registered channel with its live
 * connection status, account, QR login surface, and management actions
 * (re-login / logout). Data arrives through the injected `channelAdmin`
 * Remote faces; the section polls the snapshot so login progress (QR shown →
 * scanned → confirmed) reflects without manual refresh.
 */
import { type ReactNode } from 'react';
import type { ChannelSnapshot } from '@neko/neko-channel/channel';
import type { InjectFace, PropsLocale, PropsRuntime } from '@neko/neko-client-ui-slots';
/** Registration-side Remote faces used by the section. */
export interface ChannelsSettingsSectionInjected {
    /** Read the current channel snapshots. */
    list: () => Promise<ChannelSnapshot[]>;
    /** Drop credentials and start a fresh login (returns the new snapshot). */
    relogin: (channelId: string) => Promise<ChannelSnapshot>;
    /** Drop credentials and disconnect (returns the new snapshot). */
    logout: (channelId: string) => Promise<ChannelSnapshot>;
}
/** Full component props assembled by the Settings slot renderer. */
export type ChannelsSettingsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.channels'> & InjectFace<ChannelsSettingsSectionInjected>;
/** Render the channel management panel. */
export declare function ChannelsSettingsSection({ list, relogin, logout, t }: ChannelsSettingsSectionProps): ReactNode;
//# sourceMappingURL=ChannelsSettingsSection.d.ts.map