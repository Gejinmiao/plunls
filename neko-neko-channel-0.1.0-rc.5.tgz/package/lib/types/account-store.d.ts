/**
 * Persistent WeChat bot credentials, kept under the Neko home so a restart
 * reconnects without another QR scan (until the gateway invalidates the
 * token).
 *
 * @module @neko/neko-channel-wechat/account-store
 */
/** One logged-in WeChat bot account. */
export interface WechatAccount {
    /** Normalized filesystem-safe account id (e.g. `b0f5860fdecb-im-bot`). */
    accountId: string;
    /** Raw ilink bot id (e.g. `b0f5860fdecb@im.bot`). */
    rawAccountId?: string;
    /** ilink bot token (Bearer). */
    token: string;
    /** Effective API base URL (may redirect to an IDC host after login). */
    baseUrl: string;
    /** The WeChat user id that scanned the QR code. */
    userId?: string;
}
/** Normalize `xxx@im.bot` / `xxx@im.wechat` to a filesystem-safe key. */
export declare function normalizeAccountId(raw: string): string;
/** The per-channel state directory under the Neko home. */
export declare function wechatStateDir(): string;
/** Every stored account, in registration order. */
export declare function listAccounts(): WechatAccount[];
/** Store one account (upsert by accountId). */
export declare function saveAccount(account: WechatAccount): void;
/** Remove one account by id. */
export declare function removeAccount(accountId: string): void;
/** Look up one account by id. */
export declare function loadAccount(accountId: string): WechatAccount | undefined;
//# sourceMappingURL=account-store.d.ts.map