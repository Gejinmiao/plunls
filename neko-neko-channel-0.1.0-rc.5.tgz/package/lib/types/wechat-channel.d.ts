/**
 * The WeChat {@link Channel} implementation over the ilink gateway: loads or
 * QR-logs-in one bot account, long-polls `getupdates`, normalizes text
 * messages into {@link ChannelInboundMessage}, and sends agent replies back.
 *
 * @module @neko/neko-channel-wechat/wechat-channel
 */
import type { Channel, ChannelAdmin, ChannelInboundMessage, ChannelSnapshot, ChannelStatus } from './channel.ts';
/** Channel plugin configuration. */
export interface WechatChannelOptions {
    /** ilink API base URL (defaults to the public gateway). */
    apiBaseUrl?: string;
    /** Long-poll timeout per getUpdates call. */
    longPollTimeoutMs?: number;
    /** Whether group messages should be answered (default: direct only). */
    roomEnabled?: boolean;
    /** Callback for QR image URLs during login (default: write to state dir). */
    onQr?: (qrcodeUrl: string) => void;
    /** Callback for login progress lines. */
    onLog?: (line: string) => void;
}
/**
 * Long-running WeChat bot channel. One account per process (multi-account
 * support is straightforward by registering more instances). The account is
 * loaded from disk when present, otherwise a QR login is driven on start.
 */
export declare class WechatChannel implements Channel, ChannelAdmin {
    readonly id = "wechat";
    readonly name = "\u5FAE\u4FE1";
    private readonly apiBaseUrl;
    private readonly longPollTimeoutMs;
    private readonly roomEnabled;
    private readonly onQr;
    private readonly onLog;
    private account;
    private statusValue;
    private getUpdatesBuf;
    private readonly contextTokens;
    private readonly messageListeners;
    private readonly statusListeners;
    private abortController;
    private started;
    /** The latest login QR image URL, surfaced in the admin snapshot. */
    private loginQrcodeUrl;
    /** The latest login progress/error line, surfaced in the admin snapshot. */
    private loginMessage;
    constructor(options?: WechatChannelOptions);
    get status(): ChannelStatus;
    start(): Promise<void>;
    stop(): Promise<void>;
    /** Admin snapshot for the Web settings surface. */
    snapshot(): ChannelSnapshot;
    /**
     * Drop the stored account and drive a fresh QR login. The old monitor is
     * stopped first so a single connection owns the gateway at a time.
     */
    relogin(): Promise<void>;
    /** Drop the stored account and disconnect. */
    logout(): Promise<void>;
    /** Mount the online state: notify the gateway and start the monitor loop. */
    private enterOnline;
    send(conversationId: string, text: string): Promise<void>;
    onMessage(listener: (message: ChannelInboundMessage) => void): () => void;
    onStatus(listener: (status: ChannelStatus) => void): () => void;
    private ensureOnline;
    private startMonitor;
    private monitorLoop;
    private handleInbound;
    private setStatus;
    private sleep;
}
//# sourceMappingURL=wechat-channel.d.ts.map