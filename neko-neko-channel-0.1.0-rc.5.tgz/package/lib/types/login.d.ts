/**
 * QR-code login flow for the ilink WeChat gateway: request a QR, hand the
 * image URL to a callback (terminal print / file / web), long-poll its status
 * until the operator scans and confirms, and return the bot credentials.
 *
 * @module @neko/neko-channel-wechat/login
 */
import { type WechatAccount } from './account-store.ts';
/** Login outcome. */
export interface QrLoginResult {
    account?: WechatAccount;
    alreadyConnected?: boolean;
    message: string;
}
/**
 * Run one QR login against the ilink gateway.
 * @param opts.apiBaseUrl - ilink host (defaults to the fixed public gateway).
 * @param opts.timeoutMs - overall login deadline.
 * @param opts.emitQr - receives every fresh QR image URL for display.
 * @param opts.emit - receives human-readable progress lines.
 * @param opts.existingTokens - locally cached tokens offered for re-binding.
 * @returns the saved credentials when confirmed, or a failure summary.
 */
export declare function loginWithQr(opts: {
    apiBaseUrl?: string;
    timeoutMs?: number;
    emitQr: (qrcodeUrl: string) => void;
    emit: (line: string) => void;
    existingTokens?: string[];
}): Promise<QrLoginResult>;
//# sourceMappingURL=login.d.ts.map