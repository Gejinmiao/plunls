/**
 * Channel bridge: the mapping from external conversations to live agents.
 * Every registered channel's inbound messages arrive here, get routed into a
 * per-conversation agent (created lazily on first message), and the agent's
 * final reply for that turn is sent back through the channel. Each external
 * conversation owns exactly one agent for the process lifetime, so a
 * conversation keeps its history and its working state between messages.
 *
 * @module @neko/neko-channel-host/bridge
 */
import type { Context } from '@neko/cordis';
import { SessionId } from '@neko/neko-session';
import type { Channel } from './channel.ts';
/** Bridge options fixed at construction. */
export interface ChannelBridgeOptions {
    /**
     * Derive the durable session id for one external conversation. Must be
     * stable across process restarts so a conversation resumes the same log.
     * @param channelId - the channel id (`wechat`).
     * @param conversationId - the external conversation id inside that channel.
     */
    sessionIdFor(channelId: string, conversationId: string): SessionId;
    /** Working directory for agents this bridge creates. */
    cwd?: string;
}
/**
 * Route inbound channel messages into agents and answers back. Register every
 * live channel with {@link register}; the bridge subscribes to its messages
 * immediately. Turns for one conversation are serialized, so a second message
 * waits for the first reply before its agent wakes again.
 */
export declare class ChannelBridge {
    private readonly ctx;
    private readonly options;
    private readonly agents;
    private readonly queues;
    private readonly unsubscribes;
    private stopping;
    /**
     * @param ctx - host context carrying `agents`, `agentDefaultModel`, and `sessions`.
     * @param options - session-id derivation and agent working directory.
     */
    constructor(ctx: Context, options: ChannelBridgeOptions);
    /**
     * Subscribe a channel to the bridge. Its inbound messages are routed from
     * here on.
     * @param channel - the channel to bridge.
     * @returns the disposer detaching the channel.
     */
    register(channel: Channel): () => void;
    /**
     * Tear down every bridged conversation: detach all channels and dispose all
     * owned agents (draining their final turns).
     */
    stop(): Promise<void>;
    private dispatch;
    private runTurn;
    private createAgent;
}
/**
 * Derive a stable session id for one channel conversation. The channel id and
 * the external conversation id are percent-encoded into a single safe segment
 * (session ids are used as storage file names), keeping the mapping
 * deterministic across restarts.
 * @param channelId - the channel id.
 * @param conversationId - the external conversation id.
 * @returns a stable branded session id.
 */
export declare function channelSessionId(channelId: string, conversationId: string): SessionId;
/** Default `sessionIdFor` used when the host does not override derivation. */
export declare function defaultSessionIdFor(channelId: string, conversationId: string): SessionId;
//# sourceMappingURL=bridge.d.ts.map