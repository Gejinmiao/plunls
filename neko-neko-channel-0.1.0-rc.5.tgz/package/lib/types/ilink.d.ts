/**
 * Minimal ilink (Weixin bot) HTTP protocol client, ported from the
 * openclaw-weixin channel adapter (Tencent/MIT). The bot authenticates with a
 * QR scan, then long-polls `getupdates` for inbound messages and posts
 * `sendmessage` replies. All bytes fields are base64 strings in JSON.
 *
 * @module @neko/neko-channel-wechat/ilink
 */
/** Fixed ilink API base URL for QR and account operations. */
export declare const ILINK_BASE_URL = "https://ilinkai.weixin.qq.com";
/** Default `bot_type` for ilink get_bot_qrcode / get_qrcode_status. */
export declare const ILINK_BOT_TYPE = "3";
/** Self-declared bot agent string (UA-style), sent for observability only. */
export declare const BOT_AGENT = "NekoHarness/0.1.0";
/** This channel's ilink app id, mirrored from the reference implementation. */
export declare const ILINK_APP_ID = "bot";
/** Common request metadata attached to every CGI request. */
export interface BaseInfo {
    channel_version: string;
    bot_agent: string;
}
export interface QrCodeResponse {
    qrcode: string;
    qrcode_img_content: string;
}
export type QrStatus = 'wait' | 'scaned' | 'confirmed' | 'expired' | 'scaned_but_redirect' | 'need_verifycode' | 'verify_code_blocked' | 'binded_redirect';
export interface QrStatusResponse {
    status: QrStatus;
    bot_token?: string;
    ilink_bot_id?: string;
    baseurl?: string;
    ilink_user_id?: string;
    redirect_host?: string;
}
/** Request a fresh login QR code. `localTokenList` re-binds existing sessions. */
export declare function getBotQrcode(opts: {
    baseUrl?: string;
    botType?: string;
    localTokenList?: string[];
    timeoutMs?: number;
}): Promise<QrCodeResponse>;
/**
 * Long-poll the QR status until the operator scans/confirms or the QR lapses.
 * `verifyCode` is forwarded when the server asks for a pairing number.
 */
export declare function pollQrStatus(opts: {
    qrcode: string;
    baseUrl?: string;
    verifyCode?: string;
    timeoutMs?: number;
}): Promise<QrStatusResponse>;
export declare const MessageItemType: {
    readonly NONE: 0;
    readonly TEXT: 1;
    readonly IMAGE: 2;
    readonly VOICE: 3;
    readonly FILE: 4;
    readonly VIDEO: 5;
};
export declare const MessageType: {
    readonly NONE: 0;
    readonly USER: 1;
    readonly BOT: 2;
};
export declare const MessageState: {
    readonly NEW: 0;
    readonly GENERATING: 1;
    readonly FINISH: 2;
};
export interface MessageItem {
    type?: number;
    create_time_ms?: number;
    msg_id?: string;
    text_item?: {
        text?: string;
    };
    image_item?: {
        url?: string;
    };
}
/** Unified inbound message (proto: WeixinMessage). */
export interface WeixinMessage {
    seq?: number;
    message_id?: number;
    from_user_id?: string;
    to_user_id?: string;
    client_id?: string;
    create_time_ms?: number;
    session_id?: string;
    group_id?: string;
    message_type?: number;
    message_state?: number;
    item_list?: MessageItem[];
    context_token?: string;
    run_id?: string;
}
export interface GetUpdatesResponse {
    ret?: number;
    errcode?: number;
    errmsg?: string;
    msgs?: WeixinMessage[];
    get_updates_buf?: string;
    longpolling_timeout_ms?: number;
}
/** Server error codes that mean the stored token is stale and must be re-scanned. */
export declare const STALE_TOKEN_ERRCODE = -14;
/**
 * Long-poll inbound messages. The `get_updates_buf` cursor must be cached
 * locally and sent back on the next call; send `''` when none is cached.
 */
export declare function getUpdates(opts: {
    baseUrl: string;
    token: string;
    getUpdatesBuf: string;
    timeoutMs?: number;
}): Promise<GetUpdatesResponse>;
/** Send one plain-text bot message into a conversation. */
export declare function sendTextMessage(opts: {
    baseUrl: string;
    token: string;
    to: string;
    text: string;
    contextToken?: string;
    timeoutMs?: number;
}): Promise<void>;
/** Tell the gateway this client is going online (best effort). */
export declare function notifyStart(opts: {
    baseUrl: string;
    token: string;
    timeoutMs?: number;
}): Promise<void>;
/** Tell the gateway this client is going offline (best effort). */
export declare function notifyStop(opts: {
    baseUrl: string;
    token: string;
    timeoutMs?: number;
}): Promise<void>;
//# sourceMappingURL=ilink.d.ts.map