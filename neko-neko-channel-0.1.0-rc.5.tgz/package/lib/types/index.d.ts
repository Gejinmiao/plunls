/**
 * @neko/neko-channel — self-contained WeChat channel plugin pack. Mounts the
 * channel host (registry + bridge + admin gateway), then registers the WeChat
 * connector on it. The browser settings panel is contributed through the same
 * package's `neko.client` half (`src/client`).
 *
 * This is an unofficial personal-WeChat integration (the ilink protocol has
 * account-risk and may be restricted by Tencent at any time). Use at your own
 * risk.
 *
 * @module @neko/neko-channel
 */
import { Service } from '@neko/cordis';
import type { Context } from '@neko/cordis';
import z from '@neko/schemastery';
import { ChannelBridge } from './bridge.ts';
import type { Channel } from './channel.ts';
export type { Channel, ChannelAdmin, ChannelInboundMessage, ChannelSnapshot, ChannelStatus } from './channel.ts';
export { ChannelBridge, channelSessionId, defaultSessionIdFor } from './bridge.ts';
/** Stable Cordis plugin name. */
export declare const name = "channel";
/** Services required before a channel can bridge conversations. */
export declare const inject: string[];
/** Plugin config: connection tuning and inbound policy. */
export interface Config {
    /** Whether the WeChat channel should start on plugin mount. */
    enabled: boolean;
    /** ilink API base URL. */
    apiBaseUrl: string;
    /** Per-getupdates long-poll timeout in milliseconds. */
    longPollTimeoutMs: number;
    /** Whether group (room) messages are answered; direct chats always are. */
    roomEnabled: boolean;
}
export declare const Config: z<Config>;
/**
 * The live channel registry. Channels register on mount; the registry exposes
 * them for status display and management while the bridge routes their
 * messages automatically.
 */
export declare class ChannelRegistry extends Service {
    readonly bridge: ChannelBridge;
    /** Stable service name. */
    static readonly provide: "channels";
    private readonly channels;
    /**
     * @param ctx - host context (carries agents/agentDefaultModel/sessions).
     * @param bridge - the bridge new channels are wired into.
     */
    constructor(ctx: Context, bridge: ChannelBridge);
    /**
     * Register a live channel and bridge it. The bridge starts subscribing to
     * the channel's inbound messages immediately.
     * @param channel - the channel to make available.
     * @returns the disposer unregistering and detaching the channel.
     */
    register(channel: Channel): () => void;
    /** Remove one registered channel by id (no-op when absent). */
    unregister(id: string): void;
    /** Every registered channel, in registration order. */
    list(): Channel[];
    /** Look up one channel by id. */
    get(id: string): Channel | undefined;
    /** Tear down the bridge and every bridged conversation. */
    stop(): Promise<void>;
}
declare module '@neko/cordis' {
    interface Context {
        /** Registered external-message channels. */
        channels: ChannelRegistry;
    }
}
/**
 * Mount the channel host (registry + bridge + admin gateway), then register
 * and start the WeChat connector when enabled.
 * @param ctx - plugin context carrying core agent services.
 * @param config - validated channel config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map