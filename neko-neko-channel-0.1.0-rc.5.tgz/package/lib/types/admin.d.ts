/**
 * Channel admin gateway: the Remote surface the Web settings panel uses to
 * list channel states and drive lifecycle actions (re-login, logout). It
 * reads the live {@link ChannelRegistry} through the `channels` service and
 * forwards management calls only to channels that implement the optional
 * {@link ChannelAdmin} capability.
 *
 * @module @neko/neko-channel-host/admin
 */
import type { Context } from '@neko/cordis';
import { TypertRemoteService } from '@neko/neko-typert-protocol';
import type { Channel, ChannelSnapshot } from './channel.ts';
/** Whether a channel exposes the admin lifecycle capability. */
export declare function isChannelAdmin(channel: Channel): channel is Channel & {
    snapshot(): ChannelSnapshot;
    relogin(): Promise<void>;
    logout(): Promise<void>;
};
/** Remote-only service exposing channel state and lifecycle actions. */
export declare class ChannelAdminGateway extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    /** All registered channels with their current management snapshots. */
    list(): ChannelSnapshot[];
    /** Drive a fresh login on one channel (e.g. a new QR scan). */
    relogin(channelId: string): ChannelSnapshot;
    /** Log out one channel: drop stored credentials and disconnect. */
    logout(channelId: string): ChannelSnapshot;
}
export default ChannelAdminGateway;
//# sourceMappingURL=admin.d.ts.map