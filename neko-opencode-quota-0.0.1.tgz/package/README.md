# @neko-external/neko-opencode-quota

OpenCode Go 计划额度实时显示（右下角悬浮卡片）。

## 功能

- **Host 侧**：Node 原生 fetch 拉取 `https://opencode.ai/zen/go/v1/usage`（Bearer 认证）
  - 45s TTL 缓存 + 并发去重 + 60s 后台预热
  - webServer prefix API：`/@neko-external/neko-opencode-quota/api`
  - agent 工具：`_neko_external_neko_opencode_quota_status`
- **Client 侧**：`shell.overlay` 插槽右下角悬浮卡片
  - 30s 轮询 + 点击立即刷新
  - 三项额度进度条（滚动/周/月），<50% 绿 / 50-80% 黄 / >80% 红
  - 主题令牌适配亮暗主题，状态圆点 + 滚动重置时间

## 配置

API Key 在 `src/index.ts` 的 `Config.apiKey` 默认值中（可在 profile 配置覆盖）。

## 构建与安装

```bash
bash scripts/build.sh          # host 编译（src/index.ts → lib/index.js）
npm run build:client           # client 打包（src/client → lib/client.js，tsdown）
```

注入器环境内热装配（持久化，重启自动恢复）：

```
dev_install_package /root/neko/neko-opencode-quota
```

## ⚠️ 坑记录（2026-08 实测）

1. **`slots.register` 必须是双参调用**：`slots.register(options, React组件)`。
   component 是第二个参数且必须是 React 组件 `(props) => ReactNode`。
   把 component 塞进 options 单参调用 → `entry.component === undefined` →
   渲染崩溃被 abdicate（inspect 显示 occupant `active: false`，页面无卡片）。
   排查方法：`cordis_inspect_query` Slots `listSubTree({root: "shell.overlay"})` 看 occupants 的 active 标志。
2. `shell.overlay` 是点击穿透层，卡片必须自己开 `pointer-events: auto`。
3. client 构建不经过 host tsc（tsconfig 已 exclude `src/client`），
   类型检查宽松，DOM 类型错误只在浏览器运行时暴露。
