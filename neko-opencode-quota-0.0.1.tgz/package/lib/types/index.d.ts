/**
 * @neko-external/neko-opencode-quota — OpenCode Go 计划额度实时显示（右下角悬浮卡片）。
 * host 侧：Node 原生 fetch 拉取 opencode.ai 额度接口（Bearer 认证）+ 45s TTL 缓存
 * + 并发去重 + 60s 后台预热；经 webServer prefix API 暴露给 client；并注册
 * 一个 status 工具供 agent 查询。
 */
import type { Context } from '@neko/cordis';
import z from '@neko/schemastery';
export declare const name = "@neko-external/neko-opencode-quota";
export declare const inject: string[];
export interface UsageEntry {
    status: string;
    percent: number;
    resetsAt: string;
}
export interface UsageData {
    rolling: UsageEntry;
    weekly: UsageEntry;
    monthly: UsageEntry;
    fetchedAt: number;
}
export interface Config {
    /** opencode 平台 API Key（Bearer 认证） */
    apiKey: string;
    /** 额度查询接口地址 */
    endpoint: string;
    /** 缓存有效期（秒），期间内直接返回缓存 */
    ttl: number;
}
export declare const Config: z<Schemastery.ObjectS<{
    apiKey: z<string, string>;
    endpoint: z<string, string>;
    ttl: z<number, number>;
}>, Schemastery.ObjectT<{
    apiKey: z<string, string>;
    endpoint: z<string, string>;
    ttl: z<number, number>;
}>>;
export declare function apply(ctx: Context, config: Config): void;
