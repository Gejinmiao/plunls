/**
 * @neko-external/neko-opencode-quota — client 右下角额度卡片（shell.overlay 插槽）。
 * 构建：npm run build:client（tsdown，产物 lib/client.js，ModuleLoader.load 注册）。
 * 数据：每 30s 轮询 host API /@neko-external/neko-opencode-quota/api；点击卡片立即刷新。
 * ⚠️ shell.overlay 是点击穿透层，entry 必须自己开 pointer-events: auto。
 */
import type { SlotsService } from '@neko/neko-client-ui-slots';
type ClientContext = {
    slots: SlotsService;
};
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
export {};
