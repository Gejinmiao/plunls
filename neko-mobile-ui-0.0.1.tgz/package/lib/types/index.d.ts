/**
 * @neko-external/neko-mobile-ui — host 侧。
 * 1) 给 GUI 首页补 viewport-fit=cover（iPhone 刘海/底部横条安全区）。
 * 2) 把移动端布局 CSS 内联进 <head>（tapIndex）：首帧即生效，
 *    不依赖 client bundle 的加载时序；<1024px（与产品 SIDEBAR_AUTO_COLLAPSE
 *    对齐）三栏 grid 强制单列 + 侧栏变左侧抽屉，交互由 client 组件驱动。
 */
import type { Context } from '@neko/cordis';
type AppContext = Context & {
    webServer: {
        tapIndex(transform: (html: string) => string): () => void;
    };
};
export declare const name = "@neko-external/neko-mobile-ui";
export declare const inject: string[];
export declare function apply(ctx: AppContext): void;
export {};
