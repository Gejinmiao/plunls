# @neko-external/neko-mobile-ui

移动端适配：<768px 抽屉式侧栏 + 汉堡按钮 + 单列布局 + 触控/安全区优化

由 neko-super-injector dev_scaffold_plugin 生成。

## 构建与注入

```bash
NEKO_CHECKOUT=<checkout> bash scripts/build.sh
# 注入器环境内：dev_inject_plugin <本目录>
```
